# Finished Objectives

- Objective 1 : 05/09/2024
- Objective 2 : 05/09/2024
- Objective 3 : 09/09/2024
- Objective 4 : 13/09/2024
- Objective 5 : 16/09/2024
- Objective 6 : 20/09/2024